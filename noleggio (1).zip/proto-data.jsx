// proto-data.jsx — Dataset auto, host, categorie per il prototipo

const CATEGORIES = [
  { id: 'citycar', l: 'Citycar', tone: 'colored' },
  { id: 'suv', l: 'SUV', tone: 'neutral' },
  { id: 'elettrica', l: 'Elettrica', tone: 'colored' },
  { id: 'cabrio', l: 'Cabrio', tone: 'neutral' },
  { id: 'furgone', l: 'Furgone', tone: 'neutral' },
  { id: 'mensile', l: 'Lungo termine', tone: 'neutral' },
];

const HOSTS = {
  autoluca: { id: 'autoluca', n: 'AutoLuca', city: 'Sesto S.G., MI', rating: 4.9, reviews: 142, since: 'feb 2023', responseTime: '~2h', verified: true },
  greencar: { id: 'greencar', n: 'GreenCar MI', city: 'Navigli, MI', rating: 4.8, reviews: 89, since: 'gen 2024', responseTime: '~1h', verified: true },
  carhub: { id: 'carhub', n: 'CarHub Milano', city: 'Centrale, MI', rating: 4.7, reviews: 318, since: 'mag 2022', responseTime: '~4h', verified: true },
  premium: { id: 'premium', n: 'PremiumDrive', city: 'Brera, MI', rating: 4.9, reviews: 76, since: 'set 2023', responseTime: '~3h', verified: true },
};

const CARS = [
  {
    id: 'polo',
    brand: 'Volkswagen', model: 'Polo', year: 2022,
    name: 'VW Polo · 2022',
    category: 'citycar', fuel: 'Benzina', transmission: 'Manuale', seats: 5, doors: 5,
    engine: '1.0 TSI · 95cv', km: '40.000',
    pricePerDay: 32, pricePerMonth: 690,
    host: 'autoluca', city: 'Sesto S.G.', distance: '1.4 km',
    coords: [180, 240],
    hot: true,
    variant: 'hatch', tone: 'neutral', accentTone: 'colored',
    accessories: ['Apple CarPlay', 'Android Auto', 'Bluetooth', 'Sensori parcheggio', 'Cruise control', 'Aria condizionata', 'USB'],
    description: 'Polo del 2022 in ottime condizioni, ideale per la città e brevi spostamenti extraurbani. Tenuta come nuova, sempre in box. Aria condizionata, sensori posteriori, Android Auto.',
  },
  {
    id: '500e',
    brand: 'Fiat', model: '500e', year: 2023,
    name: 'Fiat 500e · 2023',
    category: 'elettrica', fuel: 'Elettrica', transmission: 'Automatico', seats: 4, doors: 3,
    engine: '42 kWh · 118cv', km: '18.000', range: '320 km',
    pricePerDay: 39, pricePerMonth: 820,
    host: 'greencar', city: 'Navigli', distance: '2.1 km',
    coords: [320, 180],
    hot: true,
    variant: 'hatch', tone: 'colored', accentTone: 'colored',
    accessories: ['Apple CarPlay', 'Android Auto', 'Bluetooth', 'Cruise control', 'Aria condizionata', 'Tetto panoramico', 'Cerchi lega'],
    description: 'Fiat 500e elettrica del 2023, perfetta per la città. 320km di autonomia, ricarica rapida. Tenuta come nuova.',
  },
  {
    id: 'clio',
    brand: 'Renault', model: 'Clio', year: 2023,
    name: 'Renault Clio · 2023',
    category: 'citycar', fuel: 'Hybrid', transmission: 'Automatico', seats: 5, doors: 5,
    engine: '1.6 Hybrid · 145cv', km: '12.000',
    pricePerDay: 42, pricePerMonth: 890,
    host: 'carhub', city: 'Centrale', distance: '2.8 km',
    coords: [220, 320],
    hot: true,
    variant: 'hatch', tone: 'neutral',
    accessories: ['Apple CarPlay', 'Android Auto', 'Bluetooth', 'Sensori parcheggio', 'Telecamera', 'Cruise control', 'Aria condizionata', 'Navigatore'],
    description: 'Clio Hybrid del 2023, ottima per consumi misti città-extra. Cambio automatico, dotata di tutto.',
  },
  {
    id: 'c3',
    brand: 'Citroën', model: 'C3', year: 2021,
    name: 'Citroën C3 · 2021',
    category: 'citycar', fuel: 'Diesel', transmission: 'Manuale', seats: 5, doors: 5,
    engine: '1.5 BlueHDi · 100cv', km: '62.000',
    pricePerDay: 28, pricePerMonth: 590,
    host: 'autoluca', city: 'Sesto', distance: '1.4 km',
    coords: [140, 280],
    variant: 'hatch', tone: 'neutral',
    accessories: ['Bluetooth', 'Aria condizionata', 'USB'],
    description: 'C3 Diesel, economica nei consumi su lunghe percorrenze. Ideale per trasferte.',
  },
  {
    id: 'a1',
    brand: 'Audi', model: 'A1', year: 2022,
    name: 'Audi A1 · 2022',
    category: 'citycar', fuel: 'Benzina', transmission: 'Automatico', seats: 5, doors: 5,
    engine: '1.0 TFSI · 110cv', km: '28.000',
    pricePerDay: 55, pricePerMonth: 1180,
    host: 'premium', city: 'Brera', distance: '3.5 km',
    coords: [380, 220],
    variant: 'sedan', tone: 'neutral',
    accessories: ['Apple CarPlay', 'Android Auto', 'Bluetooth', 'Sensori parcheggio', 'Cruise control', 'Aria condizionata', 'Cerchi lega', 'Fendinebbia'],
    description: 'A1 Sportback in versione premium. Interni curati, ottimo per chi cerca un\'auto compatta con classe.',
  },
  {
    id: '208',
    brand: 'Peugeot', model: '208', year: 2023,
    name: 'Peugeot 208 · 2023',
    category: 'citycar', fuel: 'Hybrid', transmission: 'Automatico', seats: 5, doors: 5,
    engine: '1.2 Hybrid · 100cv', km: '15.000',
    pricePerDay: 36, pricePerMonth: 770,
    host: 'carhub', city: 'Centrale', distance: '2.8 km',
    coords: [260, 380],
    hot: true,
    variant: 'hatch', tone: 'neutral',
    accessories: ['Apple CarPlay', 'Android Auto', 'Bluetooth', 'Cruise control', 'Aria condizionata'],
    description: 'Peugeot 208 Hybrid del 2023, recente e parsimoniosa.',
  },
  {
    id: 'm3',
    brand: 'Tesla', model: 'Model 3', year: 2024,
    name: 'Tesla M3 · 2024',
    category: 'elettrica', fuel: 'Elettrica', transmission: 'Automatico', seats: 5, doors: 4,
    engine: '60 kWh · 283cv', km: '6.000', range: '491 km',
    pricePerDay: 89, pricePerMonth: 1890,
    host: 'greencar', city: 'Navigli', distance: '2.1 km',
    coords: [340, 380],
    variant: 'sedan', tone: 'neutral',
    accessories: ['Apple CarPlay', 'Bluetooth', 'Autopilot', 'Tetto panoramico', 'Cerchi lega', 'Aria condizionata', 'Telecamera 360°'],
    description: 'Tesla Model 3 Standard Range del 2024. Autopilot, 491km autonomia. Esperienza guida elettrica al top.',
  },
  {
    id: 'mini',
    brand: 'Mini', model: 'Cooper', year: 2023,
    name: 'Mini Cooper · 2023',
    category: 'citycar', fuel: 'Benzina', transmission: 'Automatico', seats: 4, doors: 3,
    engine: '1.5 · 136cv', km: '22.000',
    pricePerDay: 58, pricePerMonth: 1240,
    host: 'premium', city: 'Brera', distance: '3.5 km',
    coords: [420, 280],
    variant: 'hatch', tone: 'neutral',
    accessories: ['Apple CarPlay', 'Bluetooth', 'Sensori parcheggio', 'Tetto panoramico', 'Cerchi lega', 'Fendinebbia'],
    description: 'Mini Cooper iconica, perfetta per chi cerca personalità e divertimento di guida.',
  },
];

// Hi-fi nearest hosts (for initial state)
const NEAREST_HOSTS = [
  { host: 'autoluca', distance: '1.4 km', cars: 12 },
  { host: 'greencar', distance: '2.1 km', cars: 8 },
  { host: 'carhub', distance: '2.8 km', cars: 24 },
  { host: 'premium', distance: '3.5 km', cars: 6 },
];

// Suggested locations (for the location picker)
const LOCATIONS = [
  { id: 'milano-centrale', l: 'Milano Centrale', sub: 'stazione · 320 auto disponibili', icon: 'pin' },
  { id: 'milano-linate', l: 'Milano Linate', sub: 'aeroporto · 180 auto', icon: 'pin' },
  { id: 'milano-malpensa', l: 'Milano Malpensa', sub: 'aeroporto · 410 auto', icon: 'pin' },
  { id: 'milano-sesto', l: 'Sesto San Giovanni', sub: 'quartiere · 45 auto', icon: 'pin' },
  { id: 'milano-navigli', l: 'Navigli', sub: 'zona · 62 auto', icon: 'pin' },
  { id: 'milano-brera', l: 'Brera', sub: 'zona · 38 auto', icon: 'pin' },
];

const RECENT_LOCATIONS = [
  { l: 'Roma Centro', sub: 'cercato 2 settimane fa' },
  { l: 'Catania Aeroporto', sub: 'cercato 1 mese fa' },
];

// Reviews per host (small demo set)
const REVIEWS = [
  { n: 'Marta R.', avatar: 'M', date: 'maggio 2026', stars: 5, text: 'Auto perfetta per Milano, host super disponibile. Ritiro veloce, riconsegna idem.' },
  { n: 'Stefano G.', avatar: 'S', date: 'aprile 2026', stars: 5, text: 'Esattamente come nelle foto. Consigliatissimo.' },
  { n: 'Luca P.', avatar: 'L', date: 'marzo 2026', stars: 4, text: 'Tutto bene, solo un piccolo ritardo al ritiro.' },
];

Object.assign(window, { CATEGORIES, HOSTS, CARS, NEAREST_HOSTS, LOCATIONS, RECENT_LOCATIONS, REVIEWS });
